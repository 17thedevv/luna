from pathlib import Path
import datetime, gzip, hashlib, json, re

repo = Path('D:/fdlang/.tmp-interface-debug/call-arguments-worktree')
scratch = Path('D:/fdlang/.tmp-interface-debug/named-candidate')
final = scratch / 'default-omission-final'
dest = repo / 'docs/audits/0.1-alpha-completion-2026-10-04/evidence/default-omission'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
pin = json.loads((final / 'start.json').read_text(encoding='utf-8'))
differences = [n for n, h in pin['input_hashes'].items() if not (repo / n).is_file() or sha(repo / n) != h]
cli = repo / 'luna-rs/target/debug/luna.exe'
runtime = Path('D:/fdlang/build/runtime-win/libluna-runtime.a')
report = {
    'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'base_commit': pin['base_commit'], 'input_count': len(pin['input_hashes']),
    'input_differences': differences,
    'compiler_sha256': sha(cli), 'compiler_matches_start': sha(cli) == pin['compiler_sha256'],
    'runtime_sha256': sha(runtime), 'runtime_matches_start': sha(runtime) == pin['runtime_sha256'],
    'protocol': {'compiler': 19, 'metadata': 9, 'mvir': 5, 'format': 2},
    'commands': {}, 'terminal_summaries': {}, 'raw_files': {},
    'scope': 'Synchronous omitted defaults, independent owner/method binders, generic layout and identity casts, extern forwarding, compact ABI lifetime obligations and actual receiver mapping.',
    'limitations': [
        'Async default creation-time initialization remains incorrect; native source counterexample exits 2.',
        'Fresh async artifact import rejects CorruptedData; independent HeapFree wire roundtrip demonstrates writer tag17 versus reader tag15 mismatch.',
        'Full CALL-ARGUMENTS-v1 remains PARTIAL; no full-workspace test, merge, tag, release or complete R0-R5 verdict.',
        'Consuming owned closure policy and broader provider/diagnostic/target requirements remain open.',
    ],
}
assert not differences and report['compiler_matches_start'] and report['runtime_matches_start'], report
commands = {
    'workspace-check': 'cargo check --workspace --all-targets',
    'internals': 'cargo test -p luna-ast -p luna-parser -p luna-semantic -p luna-llib -p luna-mvir -p luna-borrowck -p luna-optimizer --no-fail-fast',
    'driver-regression': 'cargo test -p luna-driver --lib --test adv_comptime_dyn_tests --test struct_lifetime_contract_acceptance_tests --test backend_fail_closed_tests --test test_sysroot_build_invariants --test lifetime_outlives_acceptance_tests --test canonical_syntax_acceptance_tests --no-fail-fast -- --nocapture',
    'cli-regression': 'cargo test -p luna-cli --test default_omission_cli --test default_arguments_cli --test named_arguments_cli --test method_resolution_cli --test namespace_alias_export_cli --test alpha_modules_cli --test comptime_loans_cli --test module_const_storage_cli --test interface_constraints_cli --no-fail-fast -- --nocapture',
    'sysroot': 'target/debug/luna.exe build-sysroot',
}
exits = json.loads((final / 'terminal-exits.json').read_text(encoding='utf-8-sig'))
for name, command in commands.items():
    report['commands'][name] = command
    log = (final / (name + '.txt')).read_text(encoding='utf-8', errors='replace')
    blocks = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored', log)
    report['terminal_summaries'][name] = {
        'shell_exit': exits[name], 'summary_blocks': len(blocks),
        'passed': sum(int(x[1]) for x in blocks), 'failed': sum(int(x[2]) for x in blocks),
        'ignored': sum(int(x[3]) for x in blocks),
    }
assert all(v == 0 for v in exits.values()), exits
dest.mkdir(parents=True, exist_ok=True)
(final / 'end.json').write_text(json.dumps({k: report[k] for k in ['recorded_utc', 'input_count', 'input_differences', 'compiler_sha256', 'compiler_matches_start', 'runtime_sha256', 'runtime_matches_start']}, indent=2) + '\n', encoding='utf-8')
# Store exact original bytes separately from readable text: preserve CRLF and BOM.
import base64
raw_snapshots = {n: base64.b64encode((repo / n).read_bytes()).decode('ascii') for n in pin['input_hashes']}
(dest / 'inputs.json.gz').write_bytes(gzip.compress(json.dumps(raw_snapshots, sort_keys=True).encode(), mtime=0))
report['input_snapshot_encoding'] = 'JSON path to base64 original file bytes; lossless gzip'
paths = list(final.glob('*'))
paths += list(scratch.glob('default-omission-*.txt'))
paths += list(scratch.glob('default-omission-*-check*.txt'))
for folder in ['default-omission-async-before', 'default-omission-method-contract-before', 'default-omission-method-contract-before-ready', 'generic-cast-before']:
    paths += [p for p in (scratch / folder).rglob('*') if p.is_file() and p.suffix in ['.txt', '.json', '.rs']]
paths += [scratch / name for name in ['archive_omission.py', 'probe_async_default.py', 'probe_heapfree_wire.rs', 'inspect_async_metadata.rs', 'async-metadata-inspector-build.txt']]
for path in sorted(set(paths)):
    if not path.is_file():
        continue
    relative = path.relative_to(scratch).as_posix()
    output = dest / (relative + '.gz')
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(gzip.compress(path.read_bytes(), mtime=0))
    report['raw_files'][relative] = {'sha256': sha(path), 'bytes': path.stat().st_size}
report['omission_cli_observations'] = {'modes': ['source', 'source_removed_relocated_artifact'], 'native_executions': 18, 'typed_negative_check_build_processes': 60}
(dest / 'exit.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
print(json.dumps({k: report[k] for k in ['input_count', 'input_differences', 'compiler_matches_start', 'runtime_matches_start', 'terminal_summaries']}, indent=2))
