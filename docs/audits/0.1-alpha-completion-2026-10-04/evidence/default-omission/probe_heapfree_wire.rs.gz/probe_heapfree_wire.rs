fn main() {
 use luna_mvir::{Module,Function,GlobalId,ValueData,Instruction,Operand,BasicBlock,LabelId,ValueId,Terminator};
 use luna_semantic::SemanticTypeId;
 let module=Module { functions: vec![Function { name:GlobalId{name:"free_probe".into(),symbol_id:None},is_extern:false,is_async:false,arg_count:0,link_name:None,param_types:vec![],ret_ty:SemanticTypeId(0),lifetime_info:Default::default(),values:vec![ValueData::new(Instruction::HeapFree{value:Operand::Number("0".into())},SemanticTypeId(0),None)],blocks:vec![BasicBlock{label:LabelId{name:"entry".into()},insts:vec![ValueId(0)],terminator:Some(Terminator::Ret{value:None})}]}]};
 let manifest=luna_llib::Manifest {identity:luna_llib::ArtifactIdentity {package_id:"probe".into(),version:"".into(),module_id:"probe".into(),artifact_id:"probe".into()},target:luna_llib::TargetContract{target_triple:"".into(),cpu:"".into(),features:"".into(),object_format:"".into(),abi:"".into(),pointer_width:64,endianness:"".into()},dependencies:Default::default(),object_metadata:None,provenance:luna_llib::Provenance {source_fingerprint:Default::default(),compiler_version:"".into(),codegen_options:"".into(),interface_fingerprint:Default::default(),execution_fingerprint:None},export_table:Default::default()};
 let mut bytes=Vec::new();luna_llib::MlibWriter::write_module(&module,&luna_ast::AstArena::new(),&[],"",manifest,None,None,&mut bytes).unwrap();
 println!("heap-free module read: {:?}",luna_llib::MlibReader::read_module(&mut std::io::Cursor::new(bytes)).map(|value|value.0));
}
