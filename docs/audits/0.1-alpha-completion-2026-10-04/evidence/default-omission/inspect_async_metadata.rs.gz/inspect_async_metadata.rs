use std::{fs,io::{Cursor,Read,Seek,SeekFrom}};
use luna_llib::{LlibHeader,SectionEntry,SectionType,SemanticMetadata};
fn main() {
 let mut reader=Cursor::new(fs::read(std::env::args().nth(1).unwrap()).unwrap());
 let header=LlibHeader::read_from(&mut reader).unwrap();
 let sections=(0..header.section_count).map(|_|SectionEntry::read_from(&mut reader).unwrap()).collect::<Vec<_>>();
 let section=sections.iter().find(|section|section.section_type==SectionType::SemanticMetadata).unwrap();
 reader.seek(SeekFrom::Start(section.offset)).unwrap();
 let mut bytes=vec![0;section.size as usize];reader.read_exact(&mut bytes).unwrap();
 let metadata:SemanticMetadata=bincode::deserialize(&bytes).unwrap();
 let interface=&metadata.interface;
 println!("anchor: {:?}",luna_llib::reader::validate_raw_storage_anchor_contracts(interface));
 println!("raw: {:?}",luna_llib::reader::validate_raw_pointer_effects(interface));
 println!("generic: {:?}",luna_llib::reader::validate_generic_contracts(interface));
 println!("callable: {:?}",luna_llib::reader::validate_callable_signatures(interface));
 println!("types: {:?}\nexports: {:?}",interface.types,interface.exported_symbols);
}
