from pathlib import Path
import os,subprocess,json,shutil,hashlib
repo=Path('D:/fdlang/.tmp-interface-debug/call-arguments-worktree')
base=Path('D:/fdlang/.tmp-interface-debug/named-candidate/default-omission-async-before')
base.mkdir(exist_ok=True)
cli=repo/'luna-rs/target/debug/luna.exe'
fixtures=repo/'tests/luna/language/default_arguments'
def copy_tree(src,dst,extensions):
    for path in src.rglob('*'):
        if path.is_file() and path.suffix in extensions:
            target=dst/path.relative_to(src); target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(path,target)
observations={'compiler_sha256':hashlib.sha256(cli.read_bytes()).hexdigest(),'runtime_sha256':hashlib.sha256(Path(os.environ['LUNA_RUNTIME_LIB']).read_bytes()).hexdigest(),'cases':[]}
for mode in ('source','artifact'):
    root=base/mode
    copy_tree(repo/'luna-rs/libs/external',root/'libs/external',{'.ln','.toml'} if mode=='source' else {'.llib','.obj','.toml'})
    project=root/'project'; project.mkdir(exist_ok=True)
    provider=project/'provider.ln'; shutil.copy2(fixtures/'async_omission_provider.ln',provider)
    env=os.environ.copy(); env['LUNA_SYSROOT']=str(root)
    def run(label,args):
        p=subprocess.run([str(cli),*map(str,args)],env=env,capture_output=True)
        (base/f'{mode}-{label}.txt').write_bytes(b'command: '+repr(args).encode()+b'\nexit: '+str(p.returncode).encode()+b'\nstdout:\n'+p.stdout+b'\nstderr:\n'+p.stderr)
        observations['cases'].append({'mode':mode,'command':label,'exit':p.returncode})
        return p
    if mode=='artifact':
        p=run('publish',['build',provider,'--lib','--emit','llib','--quiet','-o',provider.with_suffix('.llib')])
        if p.returncode: continue
        provider.unlink()
    relocated=root/'relocated'; project.rename(relocated)
    main=relocated/'main.ln'; shutil.copy2(fixtures/'async_omission_creation.ln',main)
    run('check',['check',main,'--quiet'])
    executable=relocated/'main.exe'
    built=run('build',['build',main,'--quiet','-o',executable])
    if built.returncode==0:
        p=subprocess.run([str(executable)],capture_output=True)
        (base/f'{mode}-native.txt').write_bytes(b'exit: '+str(p.returncode).encode()+b'\nstdout:\n'+p.stdout+b'\nstderr:\n'+p.stderr)
        observations['cases'].append({'mode':mode,'command':'native','exit':p.returncode,'expected_exit':0})
(base/'observations.json').write_text(json.dumps(observations,indent=2)+'\n',encoding='utf-8')
print(json.dumps(observations))
